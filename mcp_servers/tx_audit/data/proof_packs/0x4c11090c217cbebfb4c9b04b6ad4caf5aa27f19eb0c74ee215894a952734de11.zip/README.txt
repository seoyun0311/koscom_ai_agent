This archive contains an integrity proof for a single event.
Files:
- proof_pack.json: All data needed for verification
- event_raw.json: Original raw payload (if available)
Verification summary: recompute leaf, apply proof to reach merkle_root, compare.
